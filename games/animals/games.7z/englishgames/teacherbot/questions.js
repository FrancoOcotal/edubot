export const questions = [
  {
    question: "I have a pencil",
	clue: "I have a .....",
    answers: [
      '../../img/pencil.png', 
      '../../img/eraser.png', 
      '../../img/classroom.png'
    ],
    correctAnswer: '../../img/pencil.png'
  },
  {
    question: "this is my dad",
	clue: "This is my ......",
    answers: [
      '../../img/grandpa.png', 
      '../../img/glue.png', 
      '../../img/dad.png'
    ],
    correctAnswer: '../../img/dad.png'
  },
  
   {
    question: "Your doll is prettier than my doll",
	clue: "Your doll is ..... than my doll",
    answers: [
      '../../img/priti.png', 
      '../../img/pretty.png', 
      '../../img/prettier.png'
    ],
    correctAnswer: '../../img/prettier.png'
  }
  // Añade más preguntas según sea necesario
];
