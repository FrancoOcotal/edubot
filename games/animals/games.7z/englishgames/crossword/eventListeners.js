// eventListeners.js
'use strict';

import { showErrors, solveCrossword, clearGame, handleClick, handleWriting, handleKeyDown, handleFocus } from './interactions.js';

// Agregar listeners
table.addEventListener('mousedown', handleClick);
table.addEventListener('touchstart', handleClick, { passive: true });
table.addEventListener('input', handleWriting);
table.addEventListener('keydown', handleKeyDown);
checkBtn.addEventListener('click', showErrors);
solveBtn.addEventListener('click', solveCrossword);
clearBtn.addEventListener('click', clearGame);
closeBtn.addEventListener('click', () => dialog.close());
cells.forEach((cell) => cell.addEventListener('focus', handleFocus));
