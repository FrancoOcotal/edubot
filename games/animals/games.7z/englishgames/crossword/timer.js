// timer.js
'use strict';

export function startTimer() {
    start = true;
    timer = setInterval(setTime, 1000);
}

export function setTime() {
    totalSeconds++;
    seconds.innerHTML = pad(totalSeconds % 60);
    minutes.innerHTML = pad(parseInt(totalSeconds / 60));
}

function pad(val) {
    let valString = val + '';
    return valString.length < 2 ? '0' + valString : valString;
}
