// interactions.js
'use strict';

import { saveCrossword, checkInput, getNextInput } from './helpers.js';
import { startTimer } from './timer.js';
import { handleWriting, handleClick, handleFocus, handleKeyDown } from './board.js';

export { handleWriting, handleClick, handleFocus, handleKeyDown };

// Elimina la duplicada de saveCrossword, ya que ya se importa de helpers.js
