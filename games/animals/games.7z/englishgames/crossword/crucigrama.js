'use strict';

/*************************
 *       Variables       *
 *************************/

let errorShown = false;
let across = true;
let clueText;
let start = false;
let totalSeconds = JSON.parse(localStorage.getItem('timer')) || 0;
let crossword = JSON.parse(localStorage.getItem('crossword')) || {};
let timer;
let errors = JSON.parse(localStorage.getItem('errors')) || 0;
let score = JSON.parse(localStorage.getItem('score')) || 0;
let cluesData;

const minutes = document.querySelector('.minutes');
const seconds = document.querySelector('.seconds');
const table = document.querySelector('.table');
const cells = document.querySelectorAll('.letter');
const clueBox = document.querySelector('.clue-box');
const checkBtn = document.querySelector('.btn-check');
const solveBtn = document.querySelector('.btn-solve');
const clearBtn = document.querySelector('.btn-clear');
const closeBtn = document.querySelector('.dialog-close-btn');
const dialog = document.querySelector('.dialog');
const form = document.querySelector('.form');
const scoreLevel = document.querySelector('.score');
const scoreText = document.querySelector('.score-text');
dialogPolyfill.registerDialog(dialog);

/*************************
 *       Listeners       *
 *************************/

table.addEventListener('mousedown', handleClick);
table.addEventListener('touchstart', handleClick, { passive: true });
table.addEventListener('input', handleWriting);
table.addEventListener('keydown', handleKeyDown);
checkBtn.addEventListener('click', showErrors);
solveBtn.addEventListener('click', solveCrossword);
clearBtn.addEventListener('click', clearGame);
closeBtn.addEventListener('click', () => dialog.close());
cells.forEach((cell) => cell.addEventListener('focus', handleFocus));

/*************************
 *         Start        *
 *************************/

startGame();

function startGame() {
    fetchClues();
    if (Object.keys(crossword).length > 0) {
        //check and paint localStorage data in DOM
        const keysArr = Object.keys(crossword);
        keysArr.forEach((key) => {
            let cell = document.getElementById(key);
            cell.value = crossword[key];
        });
    }
    if (totalSeconds > 0) {
        setTime();
    }
}

/*************************
 *        Buttons        *
 *************************/

function showErrors() {
    if (errorShown) {
        document.documentElement.style.setProperty(
            `--colorerror`,
            `var(--blue)`
        );
        errorShown = false;
        checkBtn.innerHTML = `mostrar errores`;
    } else {
        document.documentElement.style.setProperty(`--colorerror`, `red`);
        errorShown = true;
        checkBtn.innerHTML = `ocultar errores`;
        scoreDown();
    }
}

function solveCrossword() {
    cells.forEach((cell) => (cell.value = cell.pattern.charAt(1)));
    checkForm();
}

function clearGame() {
    window.localStorage.clear();
    removeHighligh();
    totalSeconds = -1;
    clearInterval(timer);
    start = false;
    setTime();
}

function setTwitterSharing() {
    const shareBtn = document.querySelector('.btn-share');
    let myScore = scoreLevel.innerHTML;
    const tweet = `He terminado el crucigrama de @HistoriaArteWeb y he alcanzado el nivel: ${myScore}`;
    shareBtn.href = `http://twitter.com/share?text=${tweet}&user_mentions=HistoriaArteWeb&url=${window.location.href}`;
}

/*************************
 *     LocalStorage      *
 *************************/

function saveCrossword(e) {
    const id = e.target.id;
    const letter = e.target.value;
    //save crossword object: id as key, letter as value
    crossword[id] = letter;
    localStorage.setItem('crossword', JSON.stringify(crossword));
    //save crossword timer, score and errors
    localStorage.setItem('timer', JSON.stringify(totalSeconds));
    localStorage.setItem('score', JSON.stringify(score));
    localStorage.setItem('errors', JSON.stringify(errors));
}

/*************************
 *     Flow-writing     *
 *************************/

function handleWriting(e) {
    saveCrossword(e);
    checkInput(e);
    if (checkForm()) {
        return;
    }
    if (!start) {
        startTimer();
    }
    // don't move back after deleting a letter
    if (!e.target.value) {
        return;
    }

    let td = e.target.parentElement;
    getNextInput(td).focus();
}

function getNextInput(currentCell) {
    let currentInput = currentCell.querySelector('input');
    const initialId = currentInput.id;
    if (across) {
        do {
            if (currentCell.nextElementSibling) {
                currentCell = currentCell.nextElementSibling;
            } else {
                // change row
                let tr = currentCell.parentElement;
                if (tr.nextElementSibling) {
                    tr = tr.nextElementSibling;
                } else {
                    // go to first row again
                    tr = tr.parentElement.children[0];
                }
                currentCell = tr.children[0];
            }
            currentInput = currentCell.querySelector('input');
        } while (
            currentCell.classList.contains('cell-black') ||
            (currentInput.id !== initialId &&
                (currentInput.value || !currentInput.dataset.across))
        );
        return currentInput;
    } else {
        let index = currentCell.cellIndex;
        let tr = currentCell.parentElement;
        do {
            if (tr.nextElementSibling) {
                tr = tr.nextElementSibling;
            } else {
                // change column
                tr = tr.parentElement.children[0];
                index = (index + 1) % tr.children.length;
            }
            currentCell = tr.children[index];
            currentInput = currentCell.querySelector('input');
        } while (
            currentCell.classList.contains('cell-black') ||
            (currentInput.id !== initialId &&
                (currentInput.value || !currentInput.dataset.down))
        );
        return currentInput;
    }
}

/*************************
 *  keyboard behavior   *
 *************************/

function handleKeyDown(e) {
    const td = e.target.parentElement;

    if (e.key === 'Backspace' && !e.target.value) {
        const ref = getReferences(td);
        const cells = across ? ref.x || ref.y : ref.y || ref.x;
        const index = cells.indexOf(td);

        if (index > 0) {
            cells[index - 1].querySelector('input').focus();
            e.preventDefault();
        }
        return;
    }

    if (e.key === 'Enter') {
        return handleClick(e);
    }

    if (e.key === 'ArrowRight') {
        let cell = td;

        while (cell.nextElementSibling) {
            cell = cell.nextElementSibling;
            if (!cell.classList.contains('cell-black')) {
                cell.querySelector('input').focus();
                return;
            }
        }
        return;
    }

    if (e.key === 'ArrowLeft') {
        let cell = td;

        while (cell.previousElementSibling) {
            cell = cell.previousElementSibling;
            if (!cell.classList.contains('cell-black')) {
                cell.querySelector('input').focus();
                return;
            }
        }
        return;
    }

    if (e.key === 'ArrowUp') {
        const index = td.cellIndex;
        let cell = td;
        let tr = td.parentElement;

        while (tr.previousElementSibling) {
            tr = tr.previousElementSibling;
            cell = tr.children[index];

            if (!cell.classList.contains('cell-black')) {
                cell.querySelector('input').focus();
                return;
            }
        }
        return;
    }

    if (e.key === 'ArrowDown') {
        const index = td.cellIndex;
        let cell = td;
        let tr = td.parentElement;

        while (tr.nextElementSibling) {
            tr = tr.nextElementSibling;
            cell = tr.children[index];

            if (!cell.classList.contains('cell-black')) {
                cell.querySelector('input').focus();
                return;
            }
        }
    }
}

/*************************
 *  Fetch & paint clues  *
 *************************/

function fetchClues() {
    fetch('clues.json')
        .then(function (response) {
            return response.json();
        })
        .then(function (data) {
            cluesData = data;
        });
}

function paintClue(num) {
    if (num) {
        clueBox.innerHTML = `${num}. ${
            cluesData[across ? 'across' : 'down'][num]
        }`;
    } else {
        clueBox.innerHTML = '';
    }
}

/************************************
 *  Cell direction & highlighting   *
 ************************************/

function handleClick(e) {
    if (e.type === 'touchstart') {
        e.stopPropagation();
    }
    if (document.activeElement === e.target) {
        across = !across;
        handleFocus(e);
    }
}

function handleFocus(e) {
    const td = e.target.closest('td');

    if (!td) {
        return;
    }

    removeHighligh();
    const ref = getReferences(td);
    let cells = across ? ref.x : ref.y;
    if (!cells) {
        cells = ref.x || ref.y;
        across = !across;
    }

    cells.forEach((cell) => {
        cell.classList.add('highlight');
    });

    paintClue(td.querySelector('input').dataset[across ? 'across' : 'down']);
}

function getReferences(cell) {
    return {
        x: getCells(cell, (c) => c.previousElementSibling, (c) => c.nextElementSibling),
        y: getCells(
            cell,
            (c) => c.parentElement.previousElementSibling?.children[c.cellIndex],
            (c) => c.parentElement.nextElementSibling?.children[c.cellIndex]
        )
    };
}

function getCells(cell, prev, next) {
    const cells = [cell];
    let ref = cell;

    while ((ref = prev(ref))) {
        if (ref.classList.contains('cell-black')) {
            break;
        }
        cells.unshift(ref);
    }

    ref = cell;

    while ((ref = next(ref))) {
        if (ref.classList.contains('cell-black')) {
            break;
        }
        cells.push(ref);
    }

    return cells.length > 1 ? cells : null;
}

function removeHighligh() {
    document
        .querySelectorAll('.highlight')
        .forEach((cell) => cell.classList.remove('highlight'));
}

/*************************
 *       Checking        *
 *************************/

function checkForm() {
    if (document.querySelectorAll('.letter:valid').length !== cells.length) {
        return;
    }

    if (!errors) {
        clearInterval(timer);
        setTwitterSharing();
        dialog.show();
        scoreUp();
    }
}

function checkInput(e) {
    const input = e.target;
    if (!input.checkValidity()) {
        input.classList.add('error');
        errors++;
    } else {
        input.classList.remove('error');
        errors--;
    }
}

function scoreUp() {
    const letter = scoreText.innerHTML;

    if (letter === 'A') {
        return;
    }

    scoreText.innerHTML = String.fromCharCode(letter.charCodeAt(0) - 1);

    if (letter === 'E') {
        scoreLevel.innerHTML++;
    }
}

function scoreDown() {
    const letter = scoreText.innerHTML;

    if (letter === 'F') {
        return;
    }

    if (letter === 'D') {
        scoreLevel.innerHTML--;
    }

    scoreText.innerHTML = String.fromCharCode(letter.charCodeAt(0) + 1);
}

/*************************
 *         Timer         *
 *************************/

function startTimer() {
    start = true;
    timer = setInterval(setTime, 1000);
}

function setTime() {
    totalSeconds++;
    seconds.innerHTML = pad(totalSeconds % 60);
    minutes.innerHTML = pad(parseInt(totalSeconds / 60));
}

function pad(val) {
    let valString = val + '';
    if (valString.length < 2) {
        return '0' + valString;
    } else {
        return valString;
    }
}
