// board.js
'use strict';

import { saveCrossword, checkInput, getReferences, getNextInput } from './helpers.js';

export function handleWriting(e) {
    saveCrossword(e);
    checkInput(e);
    if (!start) {
        startTimer();
    }
    if (!e.target.value) {
        return;
    }

    let td = e.target.parentElement;
    getNextInput(td).focus();
}

export function handleClick(e) {
    if (e.type === 'touchstart') {
        e.stopPropagation();
    }
    if (document.activeElement === e.target) {
        across = !across;
        handleFocus(e);
    }
}

export function handleFocus(e) {
    const td = e.target.closest('td');
    if (!td) {
        return;
    }
    removeHighlight();
    const ref = getReferences(td);
    let cells = across ? ref.x : ref.y;
    if (!cells) {
        cells = ref.x || ref.y;
        across = !across;
    }
    cells.forEach((cell) => cell.classList.add('highlight'));
    paintClue(td.querySelector('input').dataset[across ? 'across' : 'down']);
}

export function handleKeyDown(e) {
    const td = e.target.parentElement;
    // Manejo de teclas para navegación
    // ...
}

function removeHighlight() {
    document.querySelectorAll('.highlight').forEach((cell) => cell.classList.remove('highlight'));
}

function paintClue(num) {
    if (num) {
        clueBox.innerHTML = `${num}. ${cluesData[across ? 'across' : 'down'][num]}`;
    } else {
        clueBox.innerHTML = '';
    }
}
