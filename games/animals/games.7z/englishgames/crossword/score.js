// score.js
'use strict';

export function showErrors() {
    if (errorShown) {
        document.documentElement.style.setProperty(`--colorerror`, `var(--blue)`);
        errorShown = false;
        checkBtn.innerHTML = `mostrar errores`;
    } else {
        document.documentElement.style.setProperty(`--colorerror`, `red`);
        errorShown = true;
        checkBtn.innerHTML = `ocultar errores`;
        scoreDown();
    }
}

export function solveCrossword() {
    cells.forEach((cell) => (cell.value = cell.pattern.charAt(1)));
    checkForm();
}

export function clearGame() {
    window.localStorage.clear();
    removeHighlight();
    totalSeconds = -1;
    clearInterval(timer);
    start = false;
    setTime();
}

function checkForm() {
    if (document.querySelectorAll('.letter:valid').length !== cells.length) {
        return;
    }
    if (!errors) {
        clearInterval(timer);
        setTwitterSharing();
        dialog.show();
        scoreUp();
    }
}

function scoreUp() {
    const letter = scoreText.innerHTML;
    if (letter === 'A') return;
    scoreText.innerHTML = String.fromCharCode(letter.charCodeAt(0) - 1);
    if (letter === 'E') {
        scoreLevel.innerHTML++;
    }
}

function scoreDown() {
    const letter = scoreText.innerHTML;
    if (letter === 'F') return;
    if (letter === 'D') {
        scoreLevel.innerHTML--;
    }
    scoreText.innerHTML = String.fromCharCode(letter.charCodeAt(0) + 1);
}
