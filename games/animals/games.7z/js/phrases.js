var levelPhrases = {
  1: {
   
	'yellow': '../grandpa.png',
	'purple': '../mom.png',
	'green': 'dad.png',
	'blue': '../img/sister.png',
	'pink': '../img/brother.png',
	
  },
  2: {
	  'pencil': 'pencil_1.png',
	  'notebook': 'notebook_1.png',
	  'ruler': 'ruler_1.png',
	  'glue': 'glue_1.png',
	  'eraser': 'eraser_1.png',
   
  },
  3: {
	'I have a rabbit': 'rabbit.png',
    'this is a pencil': 'pencil.png',
    'this is a monkey': 'monkey.png',
    'this is an ostrich': 'ostrich.png',
	'this is a tiger': 'tiger.png',
    'this is a lion': 'lion.png',
	'this is an owl': 'owl.png',
  },
 
};